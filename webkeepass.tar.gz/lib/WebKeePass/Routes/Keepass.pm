package WebKeepass::Routes::Keepass;
#ABSTRACT: Routes for when the DB is opened

=head1 DESCRIPTION

All the routes defined here requires the DB to be opened in session.
The prefix is set to '/keepass'

=cut

use strict;
use warnings;
use Carp 'croak'; 



1;

